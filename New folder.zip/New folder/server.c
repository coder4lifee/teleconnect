#include <SFML/System.h>
#include <SFML/Network.h>
#include <stdio.h>
#include <windows.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

int main()
{
    system("cls");
    char *string[100];

    sfTcpSocket *socket = sfTcpSocket_create();
    sfTcpListener *listener = sfTcpListener_create();
    sfSocketStatus status;

    sfTcpListener_listen(listener, 47832, sfIpAddress_Any);

    printf("\x1b[36;1m ______                    ___                                                                                  __      \n");
    printf("/\\__  _\\                  /\\_ \\                                                                                /\\ \\__   \n");
    printf("\\/_/\\ \\/          __      \\//\\ \\        __       ___        ___        ___       ___        __        ___      \\ \\ ,_\\  \n");
    printf("   \\ \\ \\        /'__`\\      \\ \\ \\     /'__`\\    /'___\\     / __`\\    /' _ `\\   /' _ `\\    /'__`\\     /'___\\     \\ \\ \\/  \n");
    printf("    \\ \\ \\      /\\  __/       \\_\\ \\_  /\\  __/   /\\ \\__/    /\\ \\L\\ \\   /\\ \\/\\ \\  /\\ \\/\\ \\  /\\  __/    /\\ \\__/      \\ \\ \\_ \n");
    printf("     \\ \\_\\     \\ \\____\\      /\\____\\ \\ \\____\\  \\ \\____\\   \\ \\____/   \\ \\_\\ \\_\\ \\ \\_\\ \\_\\ \\ \\____\\   \\ \\____\\      \\ \\__\\\n");
    printf("      \\/_/      \\/____/      \\/____/  \\/____/   \\/____/    \\/___/     \\/_/\\/_/  \\/_/\\/_/  \\/____/    \\/____/       \\/__/\n\n");

    printf("\nListen for clients on port 47832.\n");
    printf("There's no place like 127.0.0.1. - John");
    // if (status == sfSocketDone)
    //{
    //    int msg_box = MessageBoxA(0, "Accept request from client?", "Server", MB_OKCANCEL | MB_ICONQUESTION);
    //   if (msg_box == IDCANCEL)
    //  {
    //      exit(0);
    // }
    //}
    while (1)
    {
        status = sfTcpListener_accept(listener, &socket);
        if (status != sfSocketDone)
        {
            // handle error...
            continue;
        }

        sfIpAddress address = sfTcpSocket_getRemoteAddress(socket);
        char string[100];
        sfIpAddress_toString(address, string);
        printf("\n\nClient has connected to server.\n\n");
        printf("Client Ip address: %s\n\n\n", address);
        printf("Port of connection: %d\n\n\n", sfTcpSocket_getRemotePort(socket));
        char data_send[256] = "\x1b[34m| The Server Of John |\x1b[3;1H";

        sfTcpSocket_send(socket, &data_send, sizeof(data_send));

        while (1)
        {
            char data[128] = {0};
            size_t size;

            int resultOfRec = sfTcpSocket_receive(socket, data, sizeof(data) - 1, &size);

            if (resultOfRec == sfSocketDisconnected)
            {
                printf("\n\n\x1b[34mClient '%s' has left the server, Joined on port %d.", string, sfTcpSocket_getRemotePort(socket));
                break;
            }

            printf("\x1b[31;23;24m%s", data);
        }
    }
}
