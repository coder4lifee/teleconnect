#include <SFML/System.h>
#include <SFML/Network.h>
#include <stdio.h>
#include <windows.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

int main()
{
    system("cls");
    
    sfTcpSocket *socket = sfTcpSocket_create();
    sfIpAddress address = sfIpAddress_fromString("localhost");

    unsigned short port = 47832;

    printf("\x1b[36;1m ______                    ___                                                                                  __      \n");
    printf("/\\__  _\\                  /\\_ \\                                                                                /\\ \\__   \n");
    printf("\\/_/\\ \\/          __      \\//\\ \\        __       ___        ___        ___       ___        __        ___      \\ \\ ,_\\  \n");
    printf("   \\ \\ \\        /'__`\\      \\ \\ \\     /'__`\\    /'___\\     / __`\\    /' _ `\\   /' _ `\\    /'__`\\     /'___\\     \\ \\ \\/  \n");
    printf("    \\ \\ \\      /\\  __/       \\_\\ \\_  /\\  __/   /\\ \\__/    /\\ \\L\\ \\   /\\ \\/\\ \\  /\\ \\/\\ \\  /\\  __/    /\\ \\__/      \\ \\ \\_ \n");
    printf("     \\ \\_\\     \\ \\____\\      /\\____\\ \\ \\____\\  \\ \\____\\   \\ \\____/   \\ \\_\\ \\_\\ \\ \\_\\ \\_\\ \\ \\____\\   \\ \\____\\      \\ \\__\\\n");
    printf("      \\/_/      \\/____/      \\/____/  \\/____/   \\/____/    \\/___/     \\/_/\\/_/  \\/_/\\/_/  \\/____/    \\/____/       \\/__/\n\n");
    while (sfTcpSocket_connect(socket, address, port, sfTime_Zero) != sfSocketDone)
    {
        printf("Failed to connect to server, Retrying...\n");
    }

    system("cls");
    char data[128] = {0};
    size_t size;
    sfTcpSocket_receive(socket, data, sizeof(data), &size);
    printf("%s", data);
    while (1)
    {
        char data_send[256];
        printf("\x1b[36mEnter a message >");
        fgets(data_send, sizeof(data_send), stdin);
        int sent = sfTcpSocket_send(socket, data_send, sizeof(data_send));
        if (sent == sfSocketDisconnected)
        {
            printf("Server Disconnected!");
            exit(0);
        }
    }
}
